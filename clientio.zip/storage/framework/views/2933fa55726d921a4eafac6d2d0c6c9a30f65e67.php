<?php echo $__env->make('layouts.GoUserSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row ">
            <div class="col-md-12 text-right">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                    <div class="container card">
                        <div class="row ">
                            <div class=" pt-4 pr-4 pl-4  card-title col-md-4 thead-light">
                                User Details
                            </div>
                        </div>
                    </div>
                    <div class="text-right">

                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th scope="col">ID</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>

                                </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>

                                    </tr>

                                </tbody>
                            </table>
                    </div>
                        <table class="table table-striped">
                            <thead>
                            <tr>

                                <th scope="col">Case Name</th>
                                <th scope="col">Case Type</th>
                                <th scope="col">Case Details</th>

                            </tr>
                            </thead>
                            <tbody>
                            <tr>

                                <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($case->title); ?></td>
                                    <td><?php echo e($case->type); ?></td>
                                    <td><?php echo e($case->description); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>

                            </tbody>
                        </table>




                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/clientView/details.blade.php ENDPATH**/ ?>