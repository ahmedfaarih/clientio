
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title', 'Project Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 " >
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item "><a href="#"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item text-success" aria-current="page">Project Management</li>
                    </ol>

                </nav>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4  class="pl-1">All Projects</h4>
            </div>

            <div class="col-md-6 text-right pl-3">
                <button class="p-2 mb-3"><a href=<?php echo e(route('projects.create')); ?>>Add a project</a></button>
            </div>
        </div>
    </div>

    <?php if($projects->count() < 0): ?>
        <div class="container">
            <p>Sorry No Projects created</p>
        </div>
    <?php else: ?>


        <div class="container">

            <div class=""></div>
            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>

                    <th scope="col">Client</th>
                    <th scope="col ">Manage</th>
                    <th scope="col"></th>
                </tr>
                </thead>

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr>

                        <td><?php echo e($project->id); ?></td>
                        <td><a href="<?php echo e(route('projects.show', $project->id)); ?>"><?php echo e($project->title); ?></a></td>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->id == $project->user_id): ?>
                        <td><?php echo e($user->name); ?></td>
                               <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th scope="row"><a class="btn btn-warning text-dark btn-outline" href=" <?php echo e(route('projects.edit', $project )); ?>" role="button">Edit</a></th>
                        <td scope="row">
                            <form action="<?php echo e(route('projects.destroy', $project->id)); ?> " class="form" role="form" method="POST">
                                <input type="hidden" name="_method" value="delete">
                                <?php echo e(csrf_field()); ?>

                                <input class="btn btn-danger" type="submit" value="Delete" >
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/projects/index.blade.php ENDPATH**/ ?>