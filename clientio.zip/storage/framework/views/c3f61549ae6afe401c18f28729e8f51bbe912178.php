
<!DOCTYPE html>
<html>

<head>
    <?php echo $__env->yieldContent('layouts.header'); ?>
</head>

<body>
<!-- Sidenav -->
<?php echo $__env->yieldContent('layouts.sidebar'); ?>


<!-- Main content -->
<div class="main-content" id="panel">


    <!-- Topnav -->
    <?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Header -->





    <!-- Header -->


    <!-- Page content -->
    <div class="container ">
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
        <!-- Footer -->
        <footer class="footer pt-0 text-center">
          &copy MN LAWYERS  <?php echo e(date('Y')); ?>

        </footer>

</div>
<!-- Argon Scripts -->
<!-- Core -->

<!-- Optional JS -->

<!-- Argon JS -->
<script src="<?php echo e(asset('js/argon.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\clientio\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>