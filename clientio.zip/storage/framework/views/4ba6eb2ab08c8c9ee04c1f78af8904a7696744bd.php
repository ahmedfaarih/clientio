<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
    Legal Bits
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 " >
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item "><a href="#"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item text-success" aria-current="page">Website Management</li>
                    </ol>

                </nav>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4  class="pl-1">All Bits</h4>
                <a class="btn btn-default" href="<?php echo e(route('legalBits.create')); ?>">Add a new bit</a>
            </div>


        </div>
    </div>

    <?php if($legalBits->count() ==0): ?>
        <div class="container">
            <p>Sorry No bits created</p>

        </div>
    <?php else: ?>


        <div class="container">

            <div class=""></div>
            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Video</th>

                </tr>
                </thead>
                <?php $__currentLoopData = $legalBits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                    <tr>

                        <td><?php echo e($bit->id); ?></td>
                        <td><?php echo e($bit->title); ?></td>
                       <td>
                           <iframe width="300" height="150" src="https://www.youtube.com/embed/<?php echo e($bit->link); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                        </td>


                        <td scope="row">
                            <form action="<?php echo e(route('legalBits.destroy', $bit->id)); ?> " class="form" role="form" method="POST">
                                <input type="hidden" name="_method" value="delete">
                                <?php echo e(csrf_field()); ?>

                                <input class="btn btn-danger" type="submit" value="Delete" >
                            </form>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/website/legalBits/index.blade.php ENDPATH**/ ?>