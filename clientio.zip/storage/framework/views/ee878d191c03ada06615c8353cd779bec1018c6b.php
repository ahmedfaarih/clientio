
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
    New request for document
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item "><a href=<?php echo e(route('home')); ?>>Home</a></li>
                <li class="breadcrumb-item text-success" aria-current="page"><a href="#">Document requests</a></li>
                <li class="breadcrumb-item text-success" aria-current="page">New request</li>
            </ol>

            <div class="card uper">
                <div class="card-header">
                    <h2>  New Request</h2>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><br/>
                    <?php endif; ?>

                    <form action="" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="col-xs-12 col-sm-12 col-md-12">
                            <div class="form-group">
                                <strong class="mb-4" >Request title:</strong>
                                <input  type="text" name="title" class="form-control" placeholder="Request title">

                            </div>
                        </div>

                        <div class="col-md-3  form-group">
                            <label class="form-control">Client </label>
                            <select name="user_id" class="form-control">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>

        </nav>
    </div>

    <div class="container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item ">RECENTLY UPLOADED BY CLIENTS</li>
        </ol>
        <div class="conatiner">
            <div class="row">
            <?php $__currentLoopData = $documentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                <iframe src="/DocumentRequests/<?php echo e($document->file_path); ?>" width="200px" height="270px">
                </iframe>
                <h5>Request name : <strong><?php echo e($document->title); ?></strong> </h5>
                <form method="get" action="/DocumentRequests/<?php echo e($document->file_path); ?>">
                    <button type="submit">Download!</button>
                </form>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/documentRequests/create.blade.php ENDPATH**/ ?>