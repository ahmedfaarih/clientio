
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
 User Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 " >
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item "><a href="#"><i class="fas fa-home"></i></a></li>
            <li class="breadcrumb-item text-success" aria-current="page">User Management</li>
          </ol>

        </nav>
        </div>

    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h4  class="pl-1">All Users</h4>
        </div>


    </div>
</div>

<?php if($users->count() < 0): ?>
<div class="container">
<p>Sorry No users created</p>
</div>
<?php else: ?>


<div class="container">

<div class=""></div>
<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Type</th>
      <th scope="col ">Manage</th>
      <th scope="col"></th>
    </tr>
  </thead>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tbody>
    <tr>

      <td><?php echo e($user->id); ?></td>
      <td><?php echo e($user->name); ?></td>
      <td><?php echo e($user->email); ?></td>
      <td><?php echo e($user->type); ?></td>
      <th scope="row"><a class="btn btn-warning text-dark btn-outline" href="<?php echo e(route('users.edit', $user)); ?>" role="button">Edit</a></th>
        <td scope="row">
            <form action="<?php echo e(route('users.destroy', $user->id)); ?> " class="form" role="form" method="POST">
                <input type="hidden" name="_method" value="delete">
                <?php echo e(csrf_field()); ?>

                <input class="btn btn-danger" type="submit" value="Delete"  <?php if($user->hasCases($user->id)): ?> disabled <?php endif; ?>>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/users/index.blade.php ENDPATH**/ ?>