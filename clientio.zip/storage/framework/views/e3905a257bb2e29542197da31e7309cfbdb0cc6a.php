<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title',  '<?php echo e($project->title); ?>'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container ">
        <div class="row">
            <div class="col-md-12 " >
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item "><a href="<?php echo e(route('adminHome')); ?>"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item text" aria-current="page">Project Management</li>
                        <li class="breadcrumb-item text-success" aria-current="page"><?php echo e($project->title); ?></li>
                    </ol>
                </nav>
            </div>

        </div>
    </div>

    <div class="container card">
        <div class="row ">
            <div class=" pt-4 pr-4 pl-4  card-title col-md-4 thead-light">
                Project Information
            </div>
        </div>

        <div class=" row  pr-4 pl-4   ">
            <div class="col-md-4">
                <h2>Project title: </h2>
                <h4> <?php echo e($project->title); ?></h4>

            </div>
            <div class="col-md-4">
                <h2>Project type: </h2>
                <h4><?php echo e($project->type); ?></h4>
            </div>

            <div class="col-md-4">
                <h2>Client Name:  <i class="fas fa-user"></i></h2>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($project->user_id == $user->id): ?>
                        <h4>  <?php echo e($user->name); ?></h4>

                    <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            </div>
            <div class="pt-2 col-md-12">
                <h2>Description</h2>
                <p><?php echo e($project->description); ?></p>
            </div>

        </div>

        <div class="row">
        <div class="col-md-12">
            <h4>Created on</h4>
            <p><?php echo e($project->created_at); ?></p>
        </div>
        </div>
    </div>

    <div class="container card">
        <div class="row card-body">
            <div class="col-md-12">
                <h3>Latest updates of this project</h3>
                


                <table class="table table-striped">
                    <thead class="thead- text-dark ">
                    <tr>
                        <th scope="col  text-white"> Updated Date</th>
                        <th scope="col  text-white">Remarks</th>
                        <th scope="col  text-white">Manage</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($update->project_id == $project->id): ?>
                    <tr>
                        <td><?php echo e($update->date); ?></td>
                        <td><?php echo e($update->remarks); ?></td>
                        <td class="btn btn-primary "><a class="text-white" href="<?php echo e(route('updates.edit', $update->id)); ?>">Edit</a></td>

                        <td >
                            <form action="<?php echo e(route('updates.destroy', $update->id)); ?> " class="form" role="form" method="POST">
                                <input type="hidden" name="_method" value="delete">
                                <?php echo e(csrf_field()); ?>

                                <input class="btn btn-danger" type="submit" value="Delete" >
                            </form>
                        </td>
                    </tr>
                    </tbody>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <a class="btn btn-success mb-3" href="<?php echo e(route('updates.create')); ?>">New update</a>
                   

                </table>
                        
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/projects/show.blade.php ENDPATH**/ ?>