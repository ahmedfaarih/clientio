<?php echo $__env->make('layouts.GoUserSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <div class="row ">
            <div class="col-md-12 text-right">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
                    <div class="container card">
                        <div class="row ">
                            <div class=" pt-4 pr-4 pl-4  card-title col-md-4 thead-light">
                                Project Updates
                            </div>
                        </div>
                    </div>
                    <div class="text-right">
                    <?php if($updates->count()<0): ?>
                    <h2>No updates</h2>
                    <?php else: ?>
                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Remark</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $updates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($update->id); ?></th>
                                    <td><?php echo e($update->date); ?></td>
                                    <td><?php echo e($update->remarks); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    <?php endif; ?>

                  </div>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/clientView/update.blade.php ENDPATH**/ ?>