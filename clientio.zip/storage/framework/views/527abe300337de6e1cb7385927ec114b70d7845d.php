
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->startSection('title'); ?>
    Publications management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 " >
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item "><a href="#"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item text-success" aria-current="page">Publications Management</li>
                    </ol>
                </nav>
            </div>
        </div>
        <button  type="button" class="btn btn-success mb-4"><a href="<?php echo e(route('publications.create')); ?>">Create</a></button>
    </div>

    <?php if($publications->count()<0): ?>
    <div class="container">
    <h2>No pulications available</h2>
    </div>

    <?php else: ?>

    <div class="container card">
        <div class="row ">
            <table class="table table-striped">
                <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Title</th>
                    <th scope="col">Type</th>
                    <th scope="col">Status</th>
                    <th scope="col">Manage</th>
                </tr>
                </thead>

                <tbody>
                <tr>
                    <th scope="row"><?php echo e($publication->id); ?></th>
                    <td><a href="<?php echo e(route('publications.show',$publication->id)); ?>"><?php echo e($publication->title); ?></a></td>
                    <td><?php echo e($publication->type); ?></td>
                    <td><?php echo e($publication->status); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('publications.edit',$publication->id)); ?>">Edit</a></td>


                    <td scope="row">
                        <form action="<?php echo e(route('publications.destroy', $publication->id)); ?> " class="form" role="form" method="POST">
                            <input type="hidden" name="_method" value="delete">
                            <?php echo e(csrf_field()); ?>

                            <input class="btn btn-danger" type="submit" value="Delete" >
                        </form>
                    </td>

                </tbody>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\clientio\resources\views/publications/index.blade.php ENDPATH**/ ?>