<header>
    <div id="top"></div>
    <nav class="navbar navbar-light fixed-top bg-white transparency border-bottom border-light" id="transmenu">
        <div class="container-fluid"><a class="navbar-brand text-success" href="http://mnlawyers.legal/">&nbsp;</a><button class="navbar-toggler collapsed" data-toggle="collapse" id="nav1" onclick="openNav()"><span></span><span></span><span></span></button><button class="navbar-toggler" data-toggle="collapse" id="nav2" onclick="closeNav()" style="display: none"><span></span><span></span><span></span></button></div>
    </nav>
    <div class="d-flex flex-column justify-content-center align-content-center overlay-nav" id="myNav">
        <div class="d-flex flex-column justify-content-center align-items-center" id="content-nav">
            <div class="d-flex align-items-center searchbar"><input type="text" class="search_input" placeholder="Search..."><a class="search_icon" href="#"><i class="fa fa-search"></i></a></div>
            <div class="d-flex flex-column align-items-center overlay-content"><a href="http://mnlawyers.legal/">Home</a><a href="partners">Partners</a><a href="areas">Practice Areas</a><a href="values">Our Core Values</a><a href="bots">Legal Bots</a><a href="#">The Start-up Lawyers </a><a href="publications">Publications</a><a href="clientio">Clientio</a></div>
        </div>
    </div>
</header>




