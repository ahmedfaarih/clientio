@extends('layouts.dashboard')
@include('layouts.header')
@extends('layouts.sidebar')

@section('title', 'Project Management')

@section('content')
    <h>Hello</h>
@endsection
